<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    echo "Login First";
    header("location: login.php");
    
}

?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>

body{
    text-align:center;
}
table, th, td {
    border: 1px solid white;
}
th,td {
  padding:60px;
  text-align: center;
  background-color: black;
  font-family: Verdana, sans-serif;
  font-size: 15px;
  color: gray;
  font-weight:bold;  
}
th, td {
  border-bottom: 1px solid white;
  
}
table {
  border-collapse: collapse;
}
tr:hover {background-color: coral;}
tr:nth-child(even) {background-color: #B69090;}

body{
    text-align: center;
}
</style>
</head>
<body>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KCET RANK PREDICTOR</title>

    <style>
        body{
            
            background-image: url(output.avif);
            background-size: cover;
              background-position: center;
              background-repeat: no-repeat;
              background-attachment: fixed;
              height: 100vh;
              width: auto;
        }
        .container{
            /* background-color:gray; */
            padding: 40px;
            width:70%;
            margin:auto;
            margin-top:50px;
            font-size:20px;
            font-weight:bold ;
            display: flex;
            border-radius: 4%;
        }
    </style>
</head>
<body>

<p>
<div class="container">
<?php
$servername = "localhost";
$username = "root";
$password = "a";
$dbname = "major";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// $Name=$_POST['fname'];
$PHY=(int)$_POST['phytheory'];
$CHEM=(int)$_POST['chemtheory'];
$MATH=(int)$_POST['maththeory'];
$PHY_CET=(int)$_POST['phycet'];
$CHEM_CET=(int)$_POST['chemcet'];
$MATH_CET=(int)$_POST['mathcet'];

if($PHY>100 || $PHY<40){
    echo"Enter the Correct Marks";
    exit();
}

if($CHEM>100 || $CHEM<40){
    echo"Enter the Correct Marks";
    exit();
}
if($MATH>100 || $MATH<40){
    echo"Enter the Correct Marks";
    exit();
}
if($PHY_CET>60 || $PHY_CET<0){
    echo"Enter the Correct Marks";
    exit();
}
if($CHEM_CET>60 || $CHEM_CET<0){
    echo"Enter the Correct Marks";
    exit();
}
if($MATH_CET>60 || $MATH_CET<0){
    echo"Enter the Correct Marks";
    exit();
}



$TOTAL=$PHY+$CHEM+$MATH+$PHY_CET+$CHEM_CET+$MATH_CET;
$TOTAL=strval($TOTAL);
// echo $TOTAL;
// echo "\n";
$sql = "SELECT * FROM cet_ranks where TOTAL='{$TOTAL}' LIMIT 1" ;
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    while($row = mysqli_fetch_assoc($result)) {
        echo "Your Input Are As Follows<br>"."<br>";
        echo "PHYSICS THEORY MARKS:".$PHY."<br>";
        echo "CHEMISTRY THEORY MARKS:".$CHEM."<br>";
        echo "MATHS THEORY MARKS:".$MATH."<br>";
        echo "PHYSICS CET MARKS:".$PHY_CET."<br>";
        echo "CHEMISTRY CET MARKS:".$CHEM_CET."<br>";
        echo "MATHS CET MARKS:".$MATH_CET."<br><br>";
        

        echo "Expected Rank:" . $row["RANKS"]."<br>";
        echo "<br>";
        echo "Note:Rank may vary this prediction is according to previous year data set";
    
    }
    
}
else {


    echo "ENTER THE CORRECT PHY CHEM MATHS MARKS!!!!";
}

$conn->close();
?>
    
</div>
</p>

</body>

</html>
