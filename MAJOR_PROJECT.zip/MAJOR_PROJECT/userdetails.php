<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    echo "Login First";
    header("location: login.php");
    
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KCET RANK PREDICTOR</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">


    <style>
        body{
            
            background-image: url(output.avif);
            background-size: cover;
              background-position: center;
              background-repeat: no-repeat;
              background-attachment: fixed;
              height: 100vh;
              width: auto;
        }
        table { 
        width: 100%; 
        border-collapse: collapse; 
        }
        /* Zebra striping */
        tr:nth-of-type(odd) { 
        background: #eee; 
        }
        th { 
        background: #333; 
        color: white; 
        font-weight: bold; 
        }
        td, th { 
        padding: 6px; 
        border: 1px solid #ccc; 
        text-align: left; 
        }



    </style>
</head>
<body>
<div class="container" style="overflow-x:auto;">
<?php
$servername = "localhost";
$username = "root";
$password = "a";
$dbname = "major";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user= $_SESSION['username'];


$sql = "SELECT * FROM users where username='{$user}'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>Username</th><th>Password</th><th>Created At</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
      echo "<tr><td>".$row["id"]."</td><td>".$row["username"]."</td><td>".$row["password"]."</td><td>".$row["created_at"]."</td></tr>";
    }
    echo "</table>";
    
}
else {
    echo "0 results";
}

$conn->close();
?>
    
</div>
