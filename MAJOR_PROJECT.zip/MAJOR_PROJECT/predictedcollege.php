<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    echo "Login First";
    header("location: login.php");
    
}

?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
  body{
        background-image: url(output.avif);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
        height: 100vh;
        width: auto;
        font-weight:400;
        font-size:16px;
    }
table, th, td {
    border: 1px solid white;
}
th,td {
  padding:4px;
  text-align: center;
  font-family: Verdana, sans-serif;
  font-size: 20px;
  color: black;
  font-weight:bold;  
}
th,td {
  border: 2px solid gray;
  
}
table {
  border-collapse: collapse;
  border: 2px solid gray;
  
}
h3{
  text-align: center;
  display:center;
}
input {
  padding:10px;
  margin-left:20px;
  background-color:silver;
  border-radius:5px;
  font-weight:bold;
  font-size:20px;
  color:black;
}
</style>
</head>
<body>

    <div class="w3-container w3-center w3-animate-left">
      <h1>WELCOME TO KCET RANK AND COLLEGE PREDICTOR</h1>
      <p>Based on your input rank and other fields these are the some recommended colleges</p>
    </div>
    <br>
    <h3>Welcome <?php echo $_POST["fname"]; ?> Here You Go!!!!<br><br></h3>
    <h3>Your Input</h3>
    <h3>Rank:<?php echo $_POST["rank"]; ?><br></h3>
    <h3>Category:<?php echo $_POST["category"]; ?><br></h3>
    <h3>Branch:<?php echo $_POST["branch"]; ?><br></h3>

    <p>
        <input type="button" value="Create PDF" 
            id="btPrint" onclick="createPDF()" />
    </p>

<div id="tab">
<div class="w3-container w3-center w3-animate-left">
<?php
$servername = "localhost";
$username = "root";
$password = "a";
$dbname = "major";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// $Name=$_POST['fname'];
$Rank=$_POST['rank'];
$Category=$_POST['category'];
$Branch=$_POST['branch'];
$loc=$_POST['location'];
if($Rank>200000){
  echo "Enter the Rank correctly<br>";
    exit();
}
else if($Rank<0){
    echo "Enter the Rank Correctly<br>";
    exit();
  }


$sql = "SELECT * FROM cet2020 where Branch='{$Branch}' and $Category>$Rank and Location like '%$loc%' ";
$result = $conn->query($sql);


if ($result->num_rows > 0) {

  
    if($Category=="1G"){
          
        echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>1G</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["1G"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
        }
        echo "</table>";
    }
   elseif($Category=="1K"){
          
      echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>1G</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
      // output data of each row
      while($row = $result->fetch_assoc()) {
          echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["1K"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
      }
      echo "</table>";
  }
  
  elseif($Category=="1R"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>1R</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["1K"]."</td></tr>" ;     
    }
    echo "</table>";
}

  elseif($Category=="2AG"){
            
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>2AG</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["2AG"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="2AK"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>2AK</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["2AK"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="2AR"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>2AR</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["2AR"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="2BG"){
            
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>2BG</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["2BG"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="2BK"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>2BK</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["2BK"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="2BR"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>2BR</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["2BR"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="3AG"){
            
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>3AG</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["3AG"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="3AK"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>3AK</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["3AK"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="3AR"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>3AR</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["3AR"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="3BG"){
            
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>3BG</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["3BG"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="3BK"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>3BK</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["3BK"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="3BR"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>2BR</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["3BR"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="GM"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>GM</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["GM"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="GMK"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>GMK</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["GMK"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="GMR"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>GMR</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["GMR"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  elseif($Category=="SCG"){
            
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>SCG</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["SCG"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="SCK"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>SCK</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["SCK"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="SCR"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>SCR</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["SCR"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="STG"){
            
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>STG</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["STG"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="STK"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>STK</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["STK"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
  elseif($Category=="STR"){
          
    echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>STR</th><th>SNQ Quota</th><th>Management Quota</th><th>CET Quota</th><th>COMEDK Quota</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["STR"]."</td><td>".$row["SNQ Quota"]."000 RS/- </td><td>".$row["Management Quota"]."00000 RS/-</td><td>".$row["CET Quota"]."000 RS/-</td><td>".$row["COMEDK Quota"]."00000 RS/-</td></tr>" ;     
    }
    echo "</table>";
  }
  
    else{
        
      echo "<table><tr><th>CETCode</th><th>College</th><th>Location</th><th>Branch</th><th>1G</th><th>1K</th><th>1R</th><th>2AG</th><th>2AK</th><th>2AR</th><th>2BG</th><th>2BK</th><th>2BR</th><th>3AG</th><th>3AK</th><th>3AR</th><th>3BG</th><th>3BK</th><th>3BR</th><th>GM</th><th>GMK</th><th>GMR</th><th>SCG</th><th>SCK</th><th>SCR</th><th>STG</th><th>STK</th><th>STR</th></tr>";
      // output data of each row
      while($row = $result->fetch_assoc()) {
          echo "<tr><td>".$row["CETCode"]."</td><td>".$row["College"]."</td><td>".$row["Location"]."</td><td>".$row["Branch"]."</td><td>".$row["1G"]."</td><td>".$row["1K"]."</td><td>".$row["1R"]."</td><td>".$row["2AG"]."</td><td>".$row["2AK"]."</td><td>".$row["2AR"]."</td><td>".$row["2BG"]."</td><td>".$row["2BK"]."</td><td>".$row["2BR"]."</td><td>".$row["3AG"]."</td><td>".$row["3AK"]."</td><td>".$row["3AR"]."</td><td>".$row["3BG"]."</td><td>".$row["3BK"]."</td><td>".$row["3BR"]."</td><td>".$row["GM"]."</td><td>".$row["GMK"]."</td><td>".$row["GMR"]."</td><td>".$row["SCG"]."</td><td>".$row["SCK"]."</td><td>".$row["SCR"]."</td><td>".$row["STG"]."</td><td>".$row["STK"]."</td><td>".$row["STR"]."</td></tr>" ;     
      }
      echo "</table>";
    }
}
else {
    echo "0 results";
}

$conn->close();
?>

</div>
</body>

<script>
    function createPDF() {
        var sTable = document.getElementById('tab').innerHTML;

        var style = "<style>";
        style = style + "table {width: 100%;font: 17px Calibri;}";
        style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
        style = style + "padding: 2px 3px;text-align: center;}";
        style = style + "</style>";

        // CREATE A WINDOW OBJECT.
        var win = window.open('', '', 'height=700,width=700');

        win.document.write('<html><head>');
        win.document.write('<title>Recommended College</title>');   // <title> FOR PDF HEADER.
        win.document.write(style);          // ADD STYLE INSIDE THE HEAD TAG.
        win.document.write('</head>');
        win.document.write('<body>');
        win.document.write(sTable);         // THE TABLE CONTENTS INSIDE THE BODY TAG.
        win.document.write('</body></html>');

        win.document.close(); 	// CLOSE THE CURRENT WINDOW.

        win.print();    // PRINT THE CONTENTS.
    }
</script>
  </div>
</html>
