<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    echo "Login First";
    header("location: login.php");
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Predict Your Rank</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

</head>
<style>
        input[type=text], select, textarea{
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            resize: vertical;
            }

            /* Style the label to display next to the inputs */
            label {
            padding: 12px 12px 12px 0;
            display: inline-block;
            }

            /* Style the submit button */
            input[type=submit] {
            background-color: #04AA6D;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            float: right;
            }

            /* Style the container */
            .container {
            border-radius: 5px;
            padding: 20px;
            }

            /* Floating column for labels: 25% width */
            .col-25 {
            float: left;
            width: 25%;
            margin-top: 6px;
            font-size:20px;
            }

            /* Floating column for inputs: 75% width */
            .col-75 {
            float: left;
            width: 75%;
            margin-top: 6px;
            font-size:20px;
            }

            /* Clear floats after the columns */
            .row:after {
            content: "";
            display: table;
            clear: both;
            }

            /* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
            @media screen and (max-width: 600px) {
            .col-25, .col-75, input[type=submit] {
                width: 100%;
                margin-top: 0;
            }
            }
            p{
                text-align:center;
                font-size:20px;
                font-weight:bold;
            }
            body{
                background-image: url(output.avif);
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                height: 100vh;
                width: auto;
                font-weight:400;
                font-size:16px;
            }
</style>
<body>
            
        <div class="container">
            <p>Enter Your Details Here</p>
        
        <form action="rankresponse.php" method="post">
            <div class="row">
            <div class="col-25">
                <label for="phytheory">Physics Theory Marks:</label>
            </div>
            <div class="col-75">
                <input type="text" id="phytheory" name="phytheory" placeholder="Enter Your Physics Theory Marks Here..(Marks should be in the range >=40 and <=100 )" required>
            </div>
            </div>

            <div class="row">
            <div class="col-25">
                <label for="chemtheory">Chemistry Theory Marks</label>
            </div>
            <div class="col-75">
                <input type="text" id="chemtheory" name="chemtheory" placeholder="Enter Your Chemistry Theory Marks Here..(Marks should be in the range >=40 and <=100 )" required>
            </div>
            </div>
            <div class="row">
            <div class="col-25">
                <label for="mathstheory">Maths Theory Marks:</label>
            </div>
            <div class="col-75">
                <input type="text" id="maththeory" name="maththeory" placeholder="Enter Your Maths Theory Marks Here..(Marks should be in the range >=40 and <=100 )" required>
            </div>
            </div>

            <div class="row">
            <div class="col-25">
                <label for="phycet">Physics CET Marks:</label>
            </div>
            <div class="col-75">
                <input type="text" id="phycet" name="phycet" placeholder="Enter Your Physics CET Marks Here..(Marks should be in the range >=1 and <=60 )" required>
            </div>
            </div>

            <div class="row">
            <div class="col-25">
                <label for="chemcet">Chemistry CET Marks:</label>
            </div>
            <div class="col-75">
                <input type="text" id="chemcet" name="chemcet" placeholder="Enter Your Chemistry CET Marks Here..(Marks should be in the range >=1 and <=60 )" required>
            </div>
            </div>
            <div class="row">
            <div class="col-25">
                <label for="mathscet">Maths CET Marks:</label>
            </div>
            <div class="col-75">
                <input type="text" id="mathcet" name="mathcet" placeholder="Enter Your Maths CET Marks Here..(Marks should be in the range >=1 and <=60 )" required>
            </div>
            </div>



            <br><br>
            <div class="row">
            <input type="submit" value="Submit">
            </div>

        
        </form>
        </div>
        
</body>
</html>