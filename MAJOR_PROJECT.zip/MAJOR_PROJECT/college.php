<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    echo "Login First";
    header("location: login.php");
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Predict Your Rank</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

</head>
<style>
        input[type=text], select, textarea{
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            resize: vertical;
            }

            /* Style the label to display next to the inputs */
            label {
            padding: 12px 12px 12px 0;
            display: inline-block;
            }

            /* Style the submit button */
            input[type=submit] {
            background-color: #04AA6D;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            float: right;
            }

            /* Style the container */
            .container {
            border-radius: 5px;
            padding: 20px;
            }

            /* Floating column for labels: 25% width */
            .col-25 {
            float: left;
            width: 25%;
            margin-top: 6px;
            font-size:20px;
            }

            /* Floating column for inputs: 75% width */
            .col-75 {
            float: left;
            width: 75%;
            margin-top: 6px;
            font-size:20px;
            }

            /* Clear floats after the columns */
            .row:after {
            content: "";
            display: table;
            clear: both;
            }

            /* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
            @media screen and (max-width: 600px) {
            .col-25, .col-75, input[type=submit] {
                width: 100%;
                margin-top: 0;
            }
            }
            p{
                text-align:center;
                font-size:20px;
                font-weight:bold;
            }
            body{
                background-image: url(output.avif);
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                height: 100vh;
                width: auto;
                font-weight:400;
                font-size:16px;
            }    
</style>
<script>  
function validateform(){  
var rank=parseInt(document.myform.rank.value);  
// var password=document.myform.password.value;  
  
if (rank==null || rank>=200000){  
  alert("Enter Correct Rank");  
  return false;  
}
</script>
<body>
        <div class="container">
            <p>Enter Your Details Here</p>
        <form name="myform" method="post"  onsubmit="return validateform()" action="predictedcollege.php" method="post">
            <div class="row">
            <div class="col-25">
                <label for="fname">Name Of Student:</label>
            </div>
            <div class="col-75">
                <input type="text" id="fname" name="fname" placeholder="Enter Your Full Name.." required>
            </div>
            </div>

            <div class="row">
            <div class="col-25">
                <label for="rank">Rank:</label>
            </div>
            <div class="col-75">
                <input type="text" id="rank" name="rank" placeholder="Enter Your Rank Here.." required>
            </div>
            </div>

            <div class="row">
            <div class="col-25">
                <label for="country">Choose Your Category:</label>
            </div>
            <div class="col-75">

                <select id="category" name="category" required>
                <option value="1G">1G</option>
                <option value="1K">1K</option>
                <option value="1R">1R</option>
                <option value="2AG">2AG</option>
                <option value="2AK">2AK</option>
                <option value="2AR">2AR</option>
                <option value="2BG">2BG</option>
                <option value="2BK">2BK</option>
                <option value="2BR">2BR</option>
                <option value="3AG">3AG</option>
                <option value="3AK">3AK</option>
                <option value="3AR">3AR</option>
                <option value="3BG">3BG</option>
                <option value="3BK">3BK</option>
                <option value="3BR">3BR</option>
                <option value="GM">GM</option>
                <option value="GMK">GMK</option>
                <option value="GME">GMR</option>
                <option value="SCG">SCG</option>
                <option value="SCK">SCK</option>
                <option value="SCR">SCR</option>
                <option value="STG">STG</option>
                <option value="STK">STK</option>
                <option value="STR">STR</option>
                  
                </select>
            
            </div>
            </div>

            <div class="row">
            <div class="col-25">
                <label for="country">Choose Your Branch:</label>
            </div>
            <div class="col-75">

                <select id="branch" name="branch" required>
                <option value="CS">CS</option>
                <option value="IE">IE</option>
                <option value="EC">EC</option>
                <option value="EE">EE</option>
                <option value="CE">CE</option>
                <option value="ME">ME</option>
                <option value="CH">CH</option>
                </select>

            </div>
            </div>
            
            <div class="row">
            <div class="col-25">
                <label for="Location">Choose The Location:</label>
            </div>
            <div class="col-75">

                <select id="location" name="location" required>
                <option value="Bengaluru">Bengaluru</option>
                <option value="Mysore">Mysore</option>
                <option value="Davanagere">Davanagere</option>
                <option value="Chitradurga">Chitradurga</option>
                <option value="Bellary">Bellary</option>
                <option value="Shivamogga">Shivamogga</option>
                <option value="Bagalkot">Bagalkot</option>
                <option value="Vijayapura">Vijayapura</option>
                <option value="Gadag">Gadag</option>
                <option value="Haveri">Haveri</option>
                <option value="Belgaum">Belgaum</option>
                <option value="Hubli">Hubli</option>
                <option value="Dharwad">Dharwad</option>
                <option value="Tumkur">Tumkur</option>
                <option value="Udupi">Udupi</option>
                <option value="Dakshina Kannada">Dakshina Kannada</option>
                <option value="Uttara Kannada">Uttara Kannada</option>
                <option value="Koppal">Koppal</option>
                <option value="Raichur">Raichur</option>
                <option value="Ramanagara">Ramanagara</option>
                <option value="Chickaballapura">Chickaballapura</option>
                <option value="Kolar">Kolar</option>
                <option value="Chamarajanagara">Chamarajanagara</option>
                <option value="Yadagiri">Yadagiri</option>
                <option value="Gulbarga">Gulbarga</option>
                <option value="Bijapur">Bijapur</option>
                <option value="Hassan">Hasssan</option>
                <option value="Bidar">Bidar</option>
                <option value="Chikkamagaluru">Chikkamagaluru</option>
                <option value="Mangalore">Mangalore</option>
                
                
                
                </select>

            </div>
            </div>
            <br><br>
            

            <div class="row">
            <input type="submit" value="Submit">
            </div>

        
        </form>
        </div>
        
</body>
</html>