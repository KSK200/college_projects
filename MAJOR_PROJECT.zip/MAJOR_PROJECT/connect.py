
from django.shortcuts import render
from django.http import JsonResponse
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import pandas as pd

def predict_rank(request):
    if request.method == 'POST':
        # Get the input data from the POST request
        cet_score = float(request.POST['cet_score'])

        # Load the preprocessed data (csv file)
        data = pd.read_csv('preprocessed_data.csv')

        # Split the data into features (X) and target (y)
        X = data[['CET_Score']]  # Replace 'CET_Score' with your feature column name
        y = data['Rank']  # Replace 'Rank' with your target column name

        # Split the data into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Train the model
        model = LinearRegression()
        model.fit(X_train, y_train)

        # Predict the rank for the given CET score
        rank_prediction = model.predict([[cet_score]])

        # Return the predicted rank as a JSON response
        return JsonResponse({'rank_prediction': rank_prediction})

def recommend_colleges(request):
    if request.method == 'POST':
        # Get the input data from the POST request
        cet_score = float(request.POST['cet_score'])

        # Load the preprocessed data (csv file)
        data = pd.read_csv('preprocessed_data.csv')

        # Filter the data based on the given CET score
        filtered_data = data[data['CET_Score'] >= cet_score]

        # Get the top 5 recommended colleges based on rank
        top_colleges = filtered_data.sort_values('Rank').head(5)['College'].tolist()

        # Return the recommended colleges as a JSON response
        return JsonResponse({'top_colleges': top_colleges})